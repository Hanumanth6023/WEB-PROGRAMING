
   function todoList() 
   {
      var data = document.getElementById('txtData');
      var addToDoList = document.getElementById('to_do_list');
      let originalValue = `<li> ${data.value} </li>`;
      data.value = '';
      addToDoList.insertAdjacentHTML('beforeend', originalValue);
   }
