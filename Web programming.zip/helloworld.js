/*let hour=9;
if(hour>6 && hour<12){
    console.log("morning");
}
else console.log("evng");*/
function primes(number){
    for(let num=2;num<=number;num++){
        let count=0;
        for(let i=2;i<=num/2;i++)
        {
            if(num%i==0)
            {

                count++;
            }
        }
        if(num===2)
        console.log(num+"coprime");
   
    else if(count ===0){
        console.log(num + "" + "it is a prime");
        }
    }
}
primes(100);