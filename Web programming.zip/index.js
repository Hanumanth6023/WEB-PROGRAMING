function twoSum(array, target_sum) {
    for(let i=0;i<array.length-1;i++){
        for(let j=0;j<array.length;j++){
            let sum=array[i]+array[j+1];
            if(target_sum===sum){

                console.log('(',array[i],',',array[j+1],')');
            }
        }
    }

    }
  twoSum([20,30,10,40,50,60,70],50);
  

